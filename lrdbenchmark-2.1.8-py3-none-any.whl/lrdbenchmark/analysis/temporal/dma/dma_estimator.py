"""Compatibility shim for DMA estimator imports."""

from .dma_estimator_unified import DMAEstimator

__all__ = ["DMAEstimator"]
