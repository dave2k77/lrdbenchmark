"""Compatibility shim for GPH estimator imports."""

from .gph_estimator_unified import GPHEstimator

__all__ = ["GPHEstimator"]
