"""Compatibility shim for CWT estimator imports."""

from .cwt_estimator_unified import CWTEstimator

__all__ = ["CWTEstimator"]
