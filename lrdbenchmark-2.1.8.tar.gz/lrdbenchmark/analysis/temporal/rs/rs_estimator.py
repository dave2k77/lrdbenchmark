"""Compatibility shim for R/S estimator imports."""

from .rs_estimator_unified import RSEstimator

__all__ = ["RSEstimator"]
