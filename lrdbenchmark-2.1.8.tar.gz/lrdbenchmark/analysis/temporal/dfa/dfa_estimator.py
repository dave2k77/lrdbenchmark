"""Compatibility shim for DFA estimator imports."""

from .dfa_estimator_unified import DFAEstimator

__all__ = ["DFAEstimator"]
